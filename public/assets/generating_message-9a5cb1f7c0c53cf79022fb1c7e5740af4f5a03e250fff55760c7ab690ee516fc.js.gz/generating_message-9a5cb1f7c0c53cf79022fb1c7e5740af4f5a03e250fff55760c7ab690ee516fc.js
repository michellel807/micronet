// generating_message.js
;
